using Test

@timed_testset "nets/" begin
    include("nets/sequential.jl")
end